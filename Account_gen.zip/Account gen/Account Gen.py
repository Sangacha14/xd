
import os
import wget
from PIL import Image
from base64 import b64decode
from os import path
from hashlib import sha1
from os import system
from io import BytesIO
import names
from hmac import new
import sys
from os import urandom
#from keep_alive import keep_alive
from hashlib import sha1
from pyfiglet import figlet_format
from progress.bar import IncrementalBar
from base64 import b64decode
from io import BytesIO
from hashlib import sha1
import names
import random
import hmac
import platform,socket,re,uuid 
import base64
import hmac
import time
import json
from hashlib import sha1
import secmail
import random
import platform,socket,re,uuid
import json
import requests
from time import sleep
from bs4 import BeautifulSoup
from time import time as timestamp
import json
from os import path
import amino
from colored import fg, bg, attr
from pyfiglet import Figlet
import secmail
import random
import platform,socket,re,uuid
import json
import webbrowser
import requests
from hmac import new
from os import urandom, remove
from hashlib import sha1
from colored import fore, back, style, attr
import secmail
import hmac
import base64
from time import sleep
from bs4 import BeautifulSoup
from time import sleep
from bs4 import BeautifulSoup
from time import time as timestamp
from fancy_text import fancy
from amino import Client
import amino
import threading
import pyfiglet
from colored import fore, back, style, attr
attr(0)
print(fore.GREEN + style.BOLD)
print(pyfiglet.figlet_format(" Vicious", font="graffiti"))
print(pyfiglet.figlet_format("Account Creater", font="small"))
f='━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
client=Client()
dm=["Chatting"]
link=input("Chat Link :- ")
xd=Client().get_from_code(link)
cid=xd.path[1:xd.path.index("/")]


comId=cid
client=amino.Client()
#keep_alive()

try:

   p=open("accounts.json", "r")
                

except FileNotFoundError:

  with open("accounts.json", 'w') as file_:

    file_.write('')  




def captcha(url):
    return requests.post("https://captcha-do-mega.herokuapp.com/", data={"text": url}).json()['captcha']
    
def deviceId():
    identifier = os.urandom(20)
    return ("42" + identifier.hex() + hmac.new(bytes.fromhex("02B258C63559D8804321C5D5065AF320358D366F"), b"\x42" + identifier, sha1).hexdigest()).upper()



def gen_email():
    mail = secmail.SecMail()
    email = mail.generate_email()
    return email
    
def upload(url):
    link = requests.get(url)
    result = BytesIO(link.content)
    return result

def get_message(email):
    	       	try:
    	       		sleep(5)
    	       		f=email
    	       		mail = secmail.SecMail()
    	       		inbox = mail.get_messages(f)
    	       		print('ᴡᴀɪᴛ...')
    	       		for Id in inbox.id:
    	       			msg = mail.read_message(email=f, id=Id).htmlBody
    	       			bs = BeautifulSoup(msg, 'html.parser')
    	       			images = bs.find_all('a')[0]
    	       			url = (images['href']+'\n')
    	       			if url is not None:
    	       			 print('𝐒𝐞𝐧𝐝𝐢𝐧𝐠 𝐂𝐨𝐝𝐞....\n')
    	       			 print(url)
    	       			 #webbrowser.open(url)
    	       			 return url
    	       			 #wget.download(url=url,out="code.png")
    	       	except:
    	       		pass
def hwid():
    return names.get_full_name()+str(random.randint(0,10000000))+platform.version()+platform.machine()+names.get_first_name()+socket.gethostbyname(socket.gethostname())+':'.join(re.findall('..', '%012x' % uuid.getnode()))+platform.processor()
    
    
def request_verify_code(email: str,deviceId: str):
        data = {
            "identity": email,
            "type": 1,
            "deviceID": deviceId
        }
        heads={
    'Accept-Language': 'en-US', 
    'Content-Type': 'application/json; charset=utf-8', 
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 7.1; LG-UK495 Build/MRA58K; com.narvii.amino.master/3.3.33180)', 
    'Host': 'service.narvii.com', 
    'Accept-Encoding': 'gzip',
    'Connection': 'Keep-Alive',
    }
        heads["Content-Length"] = str(len(data))
        heads["NDCDEVICEID"]=deviceId
        data = json.dumps(data)
        response = requests.post(f"https://service.narvii.com/api/v1/g/s/auth/request-security-validation", data=data, headers=heads)
        return response.status_code


def geticon(client):
	urlx=client.get_all_users(size=100).profile.icon
	for url in urlx:
		if url is None or url=="None":
			pass
		else:
		  return url
		  break

def fancy_name():
	nm=''
	for i in names.get_first_name():
		nm=nm+i
	return nm
    
            
def set_acc(email):
    client.login(email, password)
    url=geticon(client)
    try:
    	 client.edit_profile(icon=upload(url))
    except:
    	pass

def online_bot(cli, comId):
        data = {
            "o": {
                "actions": ["Browsing"],
                "target": f"ndc://x{comId}/",
                "ndcId": int(comId),
                "id": "82333"
            },
            "t":304}
        data = json.dumps(data)
        sleep(2)
        cli.socket.send(data)
    	
    	    	    	
def log(cli: Client, email, password,deviceid):
    try:
        cli.login(email, password)
        SID = f"{cli.sid}"
        with open("accounts.json", 'a') as x:
            acc = f'\n{{\n"email": "{email}",\n"password": "{password}",\n"deviceid": "{deviceid}",\n"SID": "{SID}"\n}},'
            x.write(acc)
            print(" ꜱᴀᴠᴇᴅ ɪɴ ꜰɪʟᴇ ᴀᴄᴄᴏᴜɴᴛꜱ.ᴊꜱᴏɴ !")

    except Exception as b:
        print(b)

    
no=int("5")
password=input("ᴄʀᴇᴀᴛᴇ ᴘᴀꜱꜱᴡᴏʀᴅ >> ")
p=open("crash.txt").read()

for _ in range(int(no)):
    deviceid=deviceId()
    #print(deviceid)
    saveemail="echo "+deviceid+">>deviceId.txt"
    system(saveemail)
    print(f)
    values=gen_email()
    email=values
    nick=fancy_name()
    req=request_verify_code(email=email, deviceId=deviceid)
    auto=get_message(values)
    vcode=input(" 𝐄𝐧𝐭𝐞𝐫 𝐂𝐨𝐝𝐞 >>  ")
    #print(vcode)
    client.register(nickname=nick, email=email, password=password,deviceId=deviceid,verificationCode=vcode)
    log(client, email, password, deviceid)
    url=geticon(client)
    response=requests.get(f"{url}")
    file=open("sam.png","wb")
    file.write(response.content)
    file.close()
    img=open("sam.png","rb")
    client.edit_profile(icon=img)
    print(f" ᴄʀᴇᴀᴛᴇᴅ ᴀᴄᴄᴏᴜɴᴛ ᴡɪᴛʜ ɴɪᴄᴋɴᴀᴍᴇ >> {nick}")
    print(" ᴘʀᴏꜰɪʟᴇ ᴘɪᴄ ᴜᴘʟᴏᴀᴅᴇᴅ !")	  
    client.join_community(comId=comId)
    subclient=amino.SubClient(comId=comId,profile=client.profile)
    subclient.edit_profile(content=p)
    print(" ᴊᴏɪɴᴇᴅ ᴄᴏᴍᴍᴜɴɪᴛʏ !")
    online_bot(cli=client,comId=cid)
    print(f' {email} ɪꜱ ᴏɴʟɪɴᴇ !")
    client.logout()
    
